package com.example.parkingsystem.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.parkingsystem.entity.Reserva;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {}