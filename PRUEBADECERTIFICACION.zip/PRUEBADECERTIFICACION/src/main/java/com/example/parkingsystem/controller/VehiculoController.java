package com.example.parkingsystem.controller;
import com.example.parkingsystem.entity.Vehiculo;
import com.example.parkingsystem.service.VehiculoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/vehiculos")
public class VehiculoController {
    @Autowired
    private VehiculoService vehiculoService;

    @GetMapping
    public String listVehiculos(Model model) {
        List<Vehiculo> vehiculos = vehiculoService.findAll();
        model.addAttribute("vehiculos", vehiculos);
        return "vehiculos/list";
    }

    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("vehiculo", new Vehiculo());
        return "vehiculos/form";
    }

    @PostMapping
    public String createVehiculo(@ModelAttribute Vehiculo vehiculo) {
        vehiculoService.save(vehiculo);
        return "redirect:/vehiculos";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Vehiculo vehiculo = vehiculoService.findById(id);
        model.addAttribute("vehiculo", vehiculo);
        return "vehiculos/form";
    }

    @PostMapping("/{id}")
    public String updateVehiculo(@PathVariable Long id, @ModelAttribute Vehiculo vehiculo) {
        vehiculo.setId(id);
        vehiculoService.save(vehiculo);
        return "redirect:/vehiculos";
    }

    @GetMapping("/delete/{id}")
    public String deleteVehiculo(@PathVariable Long id) {
        vehiculoService.deleteById(id);
        return "redirect:/vehiculos";
    }
}
