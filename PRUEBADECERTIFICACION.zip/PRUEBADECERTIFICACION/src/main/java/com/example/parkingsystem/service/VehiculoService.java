package com.example.parkingsystem.service;

import com.example.parkingsystem.entity.Vehiculo;
import com.example.parkingsystem.repository.VehiculoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehiculoService {
    @Autowired
    private VehiculoRepository vehiculoRepository;

    public List<Vehiculo> findAll() {
        return vehiculoRepository.findAll();
    }

    public Vehiculo findById(Long id) {
        return vehiculoRepository.findById(id).orElse(null);
    }

    public void save(Vehiculo vehiculo) {
        vehiculoRepository.save(vehiculo);
    }

    public void deleteById(Long id) {
        vehiculoRepository.deleteById(id);
    }
}
