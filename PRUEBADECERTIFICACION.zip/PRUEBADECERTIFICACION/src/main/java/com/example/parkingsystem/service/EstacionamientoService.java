package com.example.parkingsystem.service;
import com.example.parkingsystem.entity.Estacionamiento;
import com.example.parkingsystem.repository.EstacionamientoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EstacionamientoService {
    @Autowired
    private EstacionamientoRepository estacionamientoRepository;

    public List<Estacionamiento> findAll() {
        return estacionamientoRepository.findAll();
    }

    public Estacionamiento findById(Long id) {
        return estacionamientoRepository.findById(id).orElse(null);
    }

    public void save(Estacionamiento estacionamiento) {
        estacionamientoRepository.save(estacionamiento);
    }

    public void deleteById(Long id) {
        estacionamientoRepository.deleteById(id);
    }
}
