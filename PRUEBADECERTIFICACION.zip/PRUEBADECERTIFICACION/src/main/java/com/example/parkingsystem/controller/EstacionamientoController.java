package com.example.parkingsystem.controller;

import com.example.parkingsystem.entity.Estacionamiento;
import com.example.parkingsystem.service.EstacionamientoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/estacionamientos")
public class EstacionamientoController {
    @Autowired
    private EstacionamientoService estacionamientoService;

    @GetMapping
    public String listEstacionamientos(Model model) {
        List<Estacionamiento> estacionamientos = estacionamientoService.findAll();
        model.addAttribute("estacionamientos", estacionamientos);
        return "estacionamientos/list";
    }

    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("estacionamiento", new Estacionamiento());
        return "estacionamientos/form";
    }

    @PostMapping
    public String createEstacionamiento(@ModelAttribute Estacionamiento estacionamiento) {
        estacionamientoService.save(estacionamiento);
        return "redirect:/estacionamientos";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Estacionamiento estacionamiento = estacionamientoService.findById(id);
        model.addAttribute("estacionamiento", estacionamiento);
        return "estacionamientos/form";
    }

    @PostMapping("/{id}")
    public String updateEstacionamiento(@PathVariable Long id, @ModelAttribute Estacionamiento estacionamiento) {
        estacionamiento.setId(id);
        estacionamientoService.save(estacionamiento);
        return "redirect:/estacionamientos";
    }

    @GetMapping("/delete/{id}")
    public String deleteEstacionamiento(@PathVariable Long id) {
        estacionamientoService.deleteById(id);
        return "redirect:/estacionamientos";
    }
}
