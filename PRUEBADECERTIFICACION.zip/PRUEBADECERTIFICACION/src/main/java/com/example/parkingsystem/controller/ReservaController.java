package com.example.parkingsystem.controller;

import com.example.parkingsystem.entity.Reserva;
import com.example.parkingsystem.service.ReservaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/reservas")
public class ReservaController {
    @Autowired
    private ReservaService reservaService;

    @GetMapping
    public String listReservas(Model model) {
        List<Reserva> reservas = reservaService.findAll();
        model.addAttribute("reservas", reservas);
        return "reservas/list";
    }

    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("reserva", new Reserva());
        return "reservas/form";
    }

    @PostMapping
    public String createReserva(@ModelAttribute Reserva reserva) {
        reservaService.save(reserva);
        return "redirect:/reservas";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Reserva reserva = reservaService.findById(id);
        model.addAttribute("reserva", reserva);
        return "reservas/form";
    }

    @PostMapping("/{id}")
    public String updateReserva(@PathVariable Long id, @ModelAttribute Reserva reserva) {
        reserva.setId(id);
        reservaService.save(reserva);
        return "redirect:/reservas";
    }

    @GetMapping("/delete/{id}")
    public String deleteReserva(@PathVariable Long id) {
        reservaService.deleteById(id);
        return "redirect:/reservas";
    }
}
