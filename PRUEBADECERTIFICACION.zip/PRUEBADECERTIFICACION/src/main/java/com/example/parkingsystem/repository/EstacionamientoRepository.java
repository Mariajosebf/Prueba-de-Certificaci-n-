package com.example.parkingsystem.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.parkingsystem.entity.Estacionamiento;

public interface EstacionamientoRepository extends JpaRepository<Estacionamiento, Long> {}
