package com.example.parkingsystem.entity;

import jakarta.persistence.*;

@Entity
public class Estacionamiento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private String direccion;
    private int capacidad;
    private double tarifaPorHora;
    private String horarioOperacion;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public int getCapacidad() {
		return capacidad;
	}
	public void setCapacidad(int capacidad) {
		this.capacidad = capacidad;
	}
	public double getTarifaPorHora() {
		return tarifaPorHora;
	}
	public void setTarifaPorHora(double tarifaPorHora) {
		this.tarifaPorHora = tarifaPorHora;
	}
	public String getHorarioOperacion() {
		return horarioOperacion;
	}
	public void setHorarioOperacion(String horarioOperacion) {
		this.horarioOperacion = horarioOperacion;
	}

   
}
