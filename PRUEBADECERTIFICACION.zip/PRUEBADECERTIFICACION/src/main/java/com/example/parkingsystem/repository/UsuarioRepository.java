package com.example.parkingsystem.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.parkingsystem.entity.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {}
